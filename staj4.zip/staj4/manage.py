# -*- coding: utf-8 -*-
"""
==============================================================================
ENTERPRISE SIEM MANAGEMENT & INTERACTIVE SOC CLI CONTROLLER (manage.py)
==============================================================================
Comprehensive CLI suite for daemon management, testing, live monitoring,
user action auditing, threat intelligence queries, and perimeter defense.

COMMANDS SUMMARY:
  1. DAEMON LIFECYCLE    : start, stop, restart, audit
  2. TESTING & SIMULATION : test, benchmark, simulate, simulate-shell
  3. LOGS & AUDITING     : logs, user-audit, tail, verify-integrity, export-report
  4. SECURITY & CTI      : cti-check, dga-check, risk, memory-scan
  5. FIREWALL & SESSIONS : status, monitor (top), ban, unban, unban-all, list-bans, sessions
  6. DATASET & TRAINING  : generate-dataset, train-models
==============================================================================
"""

import os
import sys
import time
import json
import psutil
import subprocess
import argparse
from datetime import datetime

# Ensure UTF-8 stdout encoding across all terminals (Windows CP1254/CP437 & Linux)
if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

import config
from modules.ban_manager import BanManager
from modules.db_manager import get_db_connection
from modules.smart_logger import SmartLogger
from modules.integrity_guard import LogIntegrityGuard

# ==============================================================================
# HELPER FORMATTING FUNCTIONS
# ==============================================================================

def render_progress_bar(percent: float, width: int = 16) -> str:
    """Renders a clean ASCII progress bar: [########--------]"""
    p = max(0.0, min(100.0, percent))
    filled_len = int(round(width * p / 100.0))
    bar = "#" * filled_len + "-" * (width - filled_len)
    return f"[{bar}] {p:>5.1f}%"

def format_countdown(unban_at: float, now: float) -> str:
    """Formats remaining ban seconds into mm:ss or hh:mm format."""
    remaining = max(0, int(unban_at - now))
    if remaining >= 3600:
        h = remaining // 3600
        m = (remaining % 3600) // 60
        return f"{h:02d}h {m:02d}m"
    else:
        m = remaining // 60
        s = remaining % 60
        return f"{m:02d}m {s:02d}s"

# ==============================================================================
# 1. DAEMON LIFECYCLE COMMANDS (start, stop, restart, audit)
# ==============================================================================

def start_daemon_cmd(mode="production", daemon=False, port=None):
    """Starts the SIEM engine in production or warning-only mode."""
    target_script = "main.py" if mode == "production" else "main_warning_only.py"
    cmd = [sys.executable, target_script]
    if port:
        os.environ["SIEM_SYSLOG_PORT"] = str(port)

    print(f"[*] Launching Enterprise SIEM Engine in [{mode.upper()}] mode...")
    if daemon:
        if os.name == "nt":
            # On Windows, spawn background process using creationflags
            DETACHED_PROCESS = 0x00000008
            proc = subprocess.Popen(cmd, creationflags=DETACHED_PROCESS, close_fds=True)
        else:
            proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        print(f"[OK] SIEM Daemon started in background (PID: {proc.pid}).")
    else:
        try:
            subprocess.run(cmd)
        except KeyboardInterrupt:
            print("\n[*] SIEM Process terminated cleanly.")

def stop_daemon_cmd():
    """Stops all running SIEM engine background processes."""
    print("[*] Searching for active SIEM processes...")
    current_pid = os.getpid()
    killed = 0
    for p in psutil.process_iter(['pid', 'name', 'cmdline']):
        try:
            if p.pid == current_pid:
                continue
            cmdline = " ".join(p.info.get('cmdline') or [])
            if any(target in cmdline for target in ["main.py", "main_warning_only.py", "siem-monitor"]):
                p.terminate()
                try:
                    p.wait(timeout=2)
                except psutil.TimeoutExpired:
                    p.kill()
                print(f"[+] Terminated SIEM process (PID: {p.pid})")
                killed += 1
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

    if killed > 0:
        print(f"[OK] Successfully stopped {killed} SIEM process(es).")
    else:
        print("[OK] No active SIEM processes found running.")

def restart_daemon_cmd(mode="production"):
    """Restarts the SIEM engine."""
    stop_daemon_cmd()
    time.sleep(1.0)
    start_daemon_cmd(mode=mode, daemon=True)

# ==============================================================================
# 2. TESTING & SIMULATION COMMANDS (test, benchmark, simulate, simulate-shell)
# ==============================================================================

def run_tests_cmd(section=None, verbose=False):
    """Executes the automated 17-point SIEM verification suite."""
    test_path = os.path.join("tests", "test_enterprise_siem.py")
    if not os.path.exists(test_path):
        test_path = "test_enterprise_siem.py"
    
    cmd = [sys.executable, test_path]
    print(f"[*] Running Enterprise Verification Suite ({test_path})...\n")
    subprocess.run(cmd)

def run_benchmark_cmd():
    """Executes the 25 ground-truth machine learning benchmark suite."""
    bench_path = os.path.join("tests", "test_colab.py")
    if not os.path.exists(bench_path):
        bench_path = "test_colab.py"
    
    cmd = [sys.executable, bench_path]
    print(f"[*] Running AI Security Benchmark Suite ({bench_path})...\n")
    subprocess.run(cmd)

def run_benchmark_1000_cmd():
    """Executes the 1,000 scenario multi-vector stress-test benchmark suite."""
    bench_path = os.path.join("tests", "test_colab.py")
    if not os.path.exists(bench_path):
        bench_path = "test_colab.py"
    
    cmd = [sys.executable, bench_path, "--1000"]
    print(f"[*] Running 1,000 Scenario Enterprise Stress-Test Benchmark ({bench_path})...\n")
    subprocess.run(cmd)

def run_benchmark_10000_cmd():
    """Executes the 10,000 scenario realistic enterprise stress-test benchmark suite."""
    bench_path = os.path.join("tests", "benchmark_10000.py")
    if not os.path.exists(bench_path):
        bench_path = "build_10000.py"
    
    cmd = [sys.executable, bench_path]
    print(f"[*] Running 10,000 Scenario Enterprise Realistic Stress-Test Benchmark ({bench_path})...\n")
    subprocess.run(cmd)

def simulate_command_cmd(command_str):
    """Evaluates a single command string through the AI Security Engine in dry-run mode."""
    from modules.ai_security_engine import AISecurityEngine
    from modules.canonicalizer import PayloadCanonicalizer
    from simulate_test import evaluate_command, print_result

    print("\n" + "=" * 78)
    print("           DRY-RUN SECURITY SIMULATION & AI INFERENCE")
    print("=" * 78)
    res = evaluate_command(command_str)
    print_result(res)
    print("=" * 78 + "\n")

def simulate_shell_cmd():
    """Opens interactive threat simulation REPL."""
    from simulate_test import interactive_mode
    interactive_mode()

# ==============================================================================
# 3. LOGS & AUDIT COMMANDS (status, logs, user-audit, tail, verify-integrity, export-report)
# ==============================================================================

def show_status():
    """Displays live system hardware utilization, active bans, and sessions."""
    now = time.time()
    bm = BanManager()

    print("\n" + "=" * 78)
    print("           SIEM SECURITY & SYSTEM MONITORING STATUS REPORT")
    print("=" * 78)

    # 1. Hardware Resource Utilization
    cpu_percent = psutil.cpu_percent(interval=0.5)
    ram = psutil.virtual_memory()
    disk = psutil.disk_usage("/") if os.name != 'nt' else psutil.disk_usage("C:\\")

    print(f"[*] CPU Utilization   : {render_progress_bar(cpu_percent)}")
    print(f"[*] RAM Utilization   : {render_progress_bar(ram.percent)} ({ram.used // (1024*1024)} MB / {ram.total // (1024*1024)} MB)")
    print(f"[*] Disk Utilization  : {render_progress_bar(disk.percent)} ({disk.free // (1024*1024*1024)} GB Free Space)")

    # 2. Database & Active Firewall Bans
    active_bans = []
    try:
        with get_db_connection("security_events.db") as conn:
            cursor = conn.cursor()
            cursor.execute("""SELECT ip, network_type, criticality_level, reason, unban_at 
                              FROM banned_ips WHERE is_active = 1 AND unban_at > ?""", (now,))
            active_bans = cursor.fetchall()
    except Exception as e:
        print(f"[-] DB Query Error: {e}")

    print("\n" + "-" * 78)
    print(f"  ACTIVE FIREWALL RESTRICTIONS (TOTAL ACTIVE BANS: {len(active_bans)})")
    print("-" * 78)
    if active_bans:
        print(f"{'Target (IP/CIDR)':<22} {'Network':<10} {'Level':<10} {'Remaining':<12} {'Reason'}")
        print("-" * 78)
        for ip, net, crit, reason, unban_at in active_bans:
            rem_str = format_countdown(unban_at, now)
            print(f"{ip:<22} {net:<10} {crit:<10} {rem_str:<12} {reason[:26]}")
    else:
        print("  [OK] No active IP bans currently in effect. System clean.")

    # 3. Active Terminal Sessions
    active_sessions = []
    try:
        with get_db_connection("security_events.db") as conn:
            cursor = conn.cursor()
            cursor.execute("""SELECT username, source_ip, tty_device, total_commands, last_activity_time 
                              FROM user_sessions WHERE status = 'ACTIVE'""")
            active_sessions = cursor.fetchall()
    except Exception:
        pass

    print("\n" + "-" * 78)
    print(f"  ACTIVE USER SESSIONS (TOTAL SESSIONS: {len(active_sessions)})")
    print("-" * 78)
    if active_sessions:
        print(f"{'Username':<15} {'Source IP':<20} {'Terminal':<10} {'Cmds':<6} {'Last Activity'}")
        print("-" * 78)
        for u, ip, tty, cmds, last_act in active_sessions:
            idle_mins = int((now - last_act) // 60)
            print(f"{u:<15} {ip:<20} {tty:<10} {cmds:<6} {idle_mins} mins ago")
    else:
        print("  [OK] No active user sessions detected.")

    print("=" * 78 + "\n")

def list_logs_cmd(limit=20, level=None, event_type=None, as_json=False):
    """Queries security activity logs with optional filters."""
    query = "SELECT timestamp, level, status, module, event_type, target, summary, mitre_id, ai_verdict FROM activity_logs WHERE 1=1"
    params = []
    if level:
        query += " AND level = ?"
        params.append(level.upper())
    if event_type:
        query += " AND event_type LIKE ?"
        params.append(f"%{event_type}%")
    query += " ORDER BY id DESC LIMIT ?"
    params.append(limit)

    try:
        with get_db_connection("security_events.db") as conn:
            cursor = conn.cursor()
            cursor.execute(query, tuple(params))
            rows = cursor.fetchall()

            if as_json:
                data = [{"timestamp": r[0], "level": r[1], "status": r[2], "module": r[3], "event_type": r[4], "target": r[5], "summary": r[6], "mitre_id": r[7], "ai_verdict": r[8]} for r in rows]
                print(json.dumps(data, indent=2))
                return

            print("\n" + "=" * 90)
            print(f"                 SECURITY EVENT ACTIVITY LOGS (LAST {len(rows)} EVENTS)")
            print("=" * 90)
            print(f"{'TIMESTAMP':<20} {'LEVEL':<9} {'MODULE':<14} {'TARGET':<16} {'MITRE':<8} {'SUMMARY'}")
            print("-" * 90)
            for ts, lvl, st, mod, ev, tgt, summ, mitre, ai_v in rows:
                print(f"{ts:<20} {lvl:<9} {mod:<14} {tgt:<16} {mitre:<8} {summ[:25]}")
            print("=" * 90 + "\n")
    except Exception as e:
        print(f"[-] Query Logs Error: {e}")

def user_audit_cmd(user=None, limit=20):
    """Displays human-readable user actions, target files, and services."""
    query = "SELECT timestamp, username, source_ip, tty, action_type, target_service, target_file, command, status, summary, risk_level FROM user_action_audit WHERE 1=1"
    params = []
    if user:
        query += " AND username = ?"
        params.append(user)
    query += " ORDER BY id DESC LIMIT ?"
    params.append(limit)

    try:
        with get_db_connection("security_events.db") as conn:
            cursor = conn.cursor()
            cursor.execute(query, tuple(params))
            rows = cursor.fetchall()

            print("\n" + "=" * 95)
            print("                  USER ACTION, FILE & SERVICE AUDIT LOG")
            print("=" * 95)
            if not rows:
                print("  [OK] No user action records found.")
            for ts, u, ip, tty, act, svc, f_path, cmd, st, summ, risk in rows:
                print(f"[{ts}] [USER: {u}] [IP: {ip}] [TTY: {tty}] -> {act} ({risk})")
                print(f"  |-- TARGET SERVICE : {svc}")
                print(f"  |-- AFFECTED FILE  : {f_path}")
                print(f"  |-- COMMAND        : {cmd}")
                print(f"  \\-- SUMMARY        : {summ}\n")
            print("=" * 95 + "\n")
    except Exception as e:
        print(f"[-] User Audit Query Error: {e}")

def tail_logs_cmd(follow=False, lines=15):
    """Tails the human-readable activity log."""
    log_path = os.path.join("logs", "readable_activity.log")
    if not os.path.exists(log_path):
        print(f"[-] Log file not found: {log_path}")
        return

    with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
        all_lines = f.readlines()
        tail = all_lines[-lines:] if len(all_lines) >= lines else all_lines
        for l in tail:
            sys.stdout.write(l)
        sys.stdout.flush()

        if follow:
            try:
                while True:
                    line = f.readline()
                    if line:
                        sys.stdout.write(line)
                        sys.stdout.flush()
                    else:
                        time.sleep(0.5)
            except KeyboardInterrupt:
                print("\n[*] Tail stopped.")

def verify_log_integrity_cmd(log_path="logs/activity_records.jsonl"):
    """Verifies HMAC-SHA256 log chain integrity."""
    guard = LogIntegrityGuard()
    print("\n" + "=" * 78)
    print("      CRYPTOGRAPHIC HMAC-SHA256 LOG INTEGRITY & ANTI-TAMPER AUDIT")
    print("=" * 78)
    print(f"[*] Target Log File : {log_path}")

    is_valid, total_checked, broken_line, msg = guard.verify_jsonl_log_file(log_path)
    if is_valid:
        print(f"[*] Records Verified: {total_checked:,} entries checked.")
        print(f"[OK] VERIFICATION PASSED: {msg}")
        print("[OK] Blockchain Hash Chain is 100% INTACT. Zero tampering detected.")
    else:
        print(f"[!] VERIFICATION FAILED: Corrupted or tampered at Line {broken_line}!")
        print(f"    Error Details: {msg}")
    print("=" * 78 + "\n")

def export_report(output_file="siem_security_report.json"):
    """Exports structured metrics as JSON."""
    try:
        bm = BanManager()
        categories = {}
        with get_db_connection("security_events.db") as conn:
            cursor = conn.cursor()
            try:
                cursor.execute("SELECT event_type, COUNT(*) FROM activity_logs GROUP BY event_type")
                for cat, count in cursor.fetchall():
                    categories[cat] = count
            except Exception:
                pass

        report_data = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "active_bans_count": len(bm.active_bans),
            "active_bans_list": list(bm.active_bans.keys()),
            "hardware": {
                "cpu_percent": psutil.cpu_percent(interval=None),
                "ram_percent": psutil.virtual_memory().percent,
                "disk_percent": psutil.disk_usage('/').percent if os.name != 'nt' else psutil.disk_usage('C:\\').percent
            },
            "threat_categories": categories,
            "system_status": "OPERATIONAL"
        }

        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(report_data, f, ensure_ascii=False, indent=2)

        print(f"[OK] Security Report Exported Successfully: {output_file}")
    except Exception as e:
        print(f"[-] Export Report Error: {e}")

# ==============================================================================
# 4. SECURITY & THREAT INTELLIGENCE (cti-check, dga-check, risk, memory-scan)
# ==============================================================================

def cti_check_cmd(target):
    """Checks an IP or domain against the Cyber Threat Intelligence (CTI) database."""
    from modules.cti_matcher import cti_matcher
    print(f"\n[*] Querying CTI Threat Intelligence Database for '{target}'...")
    hit = cti_matcher.match_ip(target) if (target.replace(".", "").isdigit() or ":" in target) else cti_matcher.match_domain(target)
    if hit:
        print(f"[!] [THREAT MATCH DETECTED] Target: {target}")
        print(f"    |-- Threat Type : {hit.get('threat')}")
        print(f"    |-- Confidence  : {hit.get('confidence')}%")
        print(f"    \\-- Source Feed : {hit.get('source')}\n")
    else:
        print(f"[OK] Clean: Target '{target}' not found in known CTI threat feeds.\n")

def dga_check_cmd(domain):
    """Analyzes a domain using the DGA detection engine (Shannon Entropy)."""
    from modules.dga_detector import dga_detector
    res = dga_detector.analyze(domain)
    print(f"\n[*] DGA Analysis for Domain: {domain}")
    print(f"    |-- Is DGA       : {res['is_dga']}")
    print(f"    |-- DGA Score    : {res['score']:.1f} / 100")
    print(f"    |-- Entropy      : {res['entropy']:.3f}")
    print(f"    |-- Vowel Ratio  : {res.get('vowel_ratio', 0.0):.3f}")
    print(f"    \\-- Digit Ratio  : {res.get('digit_ratio', 0.0):.3f}\n")

def risk_cmd(entity, add_points=None, reason="Manual Risk Adjustment", is_host=False):
    """Views or updates the dynamic risk score for an entity."""
    from modules.risk_scorer import risk_scorer
    if add_points:
        res = risk_scorer.add_risk(entity, float(add_points), reason, is_user=not is_host)
        print(f"[+] Added {add_points} risk points to {'Host' if is_host else 'User'} '{entity}'.")
        print(f"    New Score: {res['score']:.1f}/100 | Tier: {res['tier']}")
    else:
        score = risk_scorer.get_risk(entity, is_user=not is_host)
        tier = risk_scorer.get_tier(score)
        print(f"[*] Entity: {entity} | Score: {score:.1f}/100 | Tier: {tier}")

def memory_scan_cmd(pid=None):
    """Runs on-demand memory maps RWX and YARA scanner."""
    from modules.memory_threat_hunter import memory_threat_hunter
    if pid:
        print(f"[*] Triggering Memory & YARA Scan on PID: {pid}...")
        findings = memory_threat_hunter.scan_process(int(pid))
        if findings:
            for f in findings:
                print(f"[!] [THREAT FOUND] PID {pid} -> {f['rule_name']} ({f['threat_type']})")
        else:
            print(f"[OK] PID {pid} memory clean. Zero malicious patterns detected.")
    else:
        print("[*] Running Full System Memory Scan across active processes...")
        total_scanned = memory_threat_hunter.scan_all_running_processes()
        print(f"[OK] Full memory sweep complete ({total_scanned} processes audited).")

# ==============================================================================
# 5. PERIMETER & SESSION CONTROLLER (monitor, ban, unban, unban-all, list-bans, sessions)
# ==============================================================================

def run_live_monitor():
    """Runs the real-time interactive terminal SOC dashboard."""
    clear_cmd = "cls" if os.name == "nt" else "clear"
    try:
        while True:
            now = time.time()
            cpu_percent = psutil.cpu_percent(interval=None)
            ram = psutil.virtual_memory()
            disk = psutil.disk_usage("/") if os.name != 'nt' else psutil.disk_usage("C:\\")

            active_bans = []
            recent_logs = []
            active_sessions = []

            try:
                with get_db_connection("security_events.db") as conn:
                    cursor = conn.cursor()
                    cursor.execute("""SELECT ip, network_type, criticality_level, reason, unban_at 
                                      FROM banned_ips WHERE is_active = 1 AND unban_at > ? ORDER BY unban_at DESC LIMIT 8""", (now,))
                    active_bans = cursor.fetchall()

                    cursor.execute("""SELECT username, source_ip, tty_device, total_commands, last_activity_time 
                                      FROM user_sessions WHERE status = 'ACTIVE' LIMIT 5""")
                    active_sessions = cursor.fetchall()

                    cursor.execute("""SELECT timestamp, level, event_type, target, mitre_id 
                                      FROM activity_logs ORDER BY id DESC LIMIT 5""")
                    recent_logs = cursor.fetchall()
            except Exception:
                pass

            os.system(clear_cmd)
            t_str = time.strftime("%Y-%m-%d %H:%M:%S")

            print("+" + "=" * 76 + "+")
            print(f"|   ENTERPRISE SIEM & SOC REAL-TIME INTERACTIVE DASHBOARD                    |")
            print(f"|   Time: {t_str} | Refresh: 1.0s | Press Ctrl+C to Exit              |")
            print("+" + "=" * 76 + "+")

            print(f" [HARDWARE UTILIZATION]")
            print(f"  CPU Usage : {render_progress_bar(cpu_percent, 20)}  |  Cores: {psutil.cpu_count(logical=True)}")
            print(f"  RAM Usage : {render_progress_bar(ram.percent, 20)}  |  Used : {ram.used // (1024*1024)}MB / {ram.total // (1024*1024)}MB")
            print(f"  Disk Space: {render_progress_bar(disk.percent, 20)}  |  Free : {disk.free // (1024*1024*1024)}GB")

            print("\n" + "-" * 78)
            print(f" [ACTIVE FIREWALL RESTRICTIONS] ({len(active_bans)} Active)")
            print("-" * 78)
            if active_bans:
                print(f" {'Target (IP/CIDR)':<22} {'Network':<10} {'Level':<10} {'Countdown':<12} {'Reason'}")
                print(" " + "-" * 76)
                for ip, net, crit, reason, unban_at in active_bans:
                    rem_str = format_countdown(unban_at, now)
                    print(f" {ip:<22} {net:<10} {crit:<10} {rem_str:<12} {reason[:24]}")
            else:
                print("  [OK] No active firewall bans. Perimeter clean.")

            print("\n" + "-" * 78)
            print(f" [ACTIVE USER TERMINAL SESSIONS] ({len(active_sessions)} Active)")
            print("-" * 78)
            if active_sessions:
                print(f" {'Username':<14} {'Source IP':<20} {'TTY':<10} {'Cmds':<6} {'Inactivity'}")
                print(" " + "-" * 76)
                for u, ip, tty, cmds, last_act in active_sessions:
                    idle_s = int(now - last_act)
                    idle_fmt = f"{idle_s//60}m {idle_s%60}s"
                    print(f" {u:<14} {ip:<20} {tty:<10} {cmds:<6} {idle_fmt}")
            else:
                print("  [OK] No interactive terminal sessions active.")

            print("\n" + "-" * 78)
            print(" [LIVE SECURITY EVENT STREAM - LAST 5 EVENTS]")
            print("-" * 78)
            if recent_logs:
                for ts, lvl, ev, tgt, mitre in recent_logs:
                    short_ts = ts.split()[-1] if " " in ts else ts
                    mitre_str = f"[{mitre}]" if mitre and mitre != "N/A" else ""
                    print(f"  {short_ts} [{lvl:<8}] {ev:<28} Target: {tgt:<16} {mitre_str}")
            else:
                print("  [*] Awaiting incoming security events...")

            print("+" + "=" * 76 + "+")
            time.sleep(1.0)
    except KeyboardInterrupt:
        print("\n[*] Live Dashboard Exited Cleanly.")

def ban_ip_cmd(ip, duration=None, criticality="CRITICAL", reason="Manual Admin Ban"):
    bm = BanManager()
    bm.ban_ip(ip=ip, criticality=criticality, reason=reason, duration_override=duration)
    print(f"[OK] Target {ip} successfully banned on firewall.")

def unban_ip_cmd(ip):
    bm = BanManager()
    if ip.lower() in ["all", "--all"]:
        bm.unban_all(reason="Manual Admin Master Flush")
    else:
        bm.unban_ip(ip=ip, reason="Manual Admin Unban")
    print(f"[OK] Restriction lifted for target {ip}.")

def unban_all_cmd():
    bm = BanManager()
    bm.unban_all(reason="Manual Admin Master Flush")
    print("[OK] All firewall restrictions and database bans successfully cleared.")

def list_all_bans(active_only=False, limit=20):
    try:
        with get_db_connection("security_events.db") as conn:
            cursor = conn.cursor()
            query = "SELECT ip, reason, criticality_level, banned_at, unban_at, is_active FROM banned_ips"
            if active_only:
                query += " WHERE is_active = 1 AND unban_at > ?"
                cursor.execute(query + " ORDER BY id DESC LIMIT ?", (time.time(), limit))
            else:
                cursor.execute(query + " ORDER BY id DESC LIMIT ?", (limit,))
            rows = cursor.fetchall()
            
            print("\n" + "=" * 78)
            print("                RECENT & ACTIVE FIREWALL RESTRICTIONS")
            print("=" * 78)
            print(f" {'IP / CIDR':<20} {'LEVEL':<10} {'STATUS':<10} {'REASON':<36}")
            print("-" * 78)
            if rows:
                for ip, reason, crit, b_at, u_at, is_act in rows:
                    status = "ACTIVE" if is_act == 1 and u_at > time.time() else "EXPIRED"
                    print(f" {ip:<20} {crit:<10} {status:<10} {reason[:35]:<36}")
            else:
                print("  [OK] No ban records found.")
            print("=" * 78 + "\n")
    except Exception as e:
        print(f"[-] Query Bans Error: {e}")

def sessions_cmd(kill_target=None):
    """Lists or terminates active user terminal sessions."""
    if kill_target:
        from modules.user_session_tracker import user_session_tracker
        user_session_tracker.terminate_session_now(kill_target)
        print(f"[OK] Session termination dispatched for '{kill_target}'.")
    else:
        try:
            with get_db_connection("security_events.db") as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT session_id, username, source_ip, tty_device, start_time, total_commands, status FROM user_sessions WHERE status = 'ACTIVE'")
                rows = cursor.fetchall()
                print("\n" + "=" * 85)
                print("                    ACTIVE USER TERMINAL SESSIONS")
                print("=" * 85)
                if rows:
                    print(f" {'SESSION ID':<15} {'USER':<12} {'SOURCE IP':<18} {'TTY':<8} {'COMMANDS':<10} {'STATUS'}")
                    print("-" * 85)
                    for sid, u, ip, tty, st, cmds, status in rows:
                        print(f" {sid:<15} {u:<12} {ip:<18} {tty:<8} {cmds:<10} {status}")
                else:
                    print("  [OK] Zero active terminal sessions.")
                print("=" * 85 + "\n")
        except Exception as e:
            print(f"[-] Query Sessions Error: {e}")

# ==============================================================================
# 6. DATASET & MODEL TRAINING SHORTCUTS (generate-dataset, train-models)
def generate_dataset_cmd(samples=5000, output="data/dataset.jsonl"):
    """Generates synthetic combinatorial log datasets."""
    from tools.generate_dataset import generate_streaming_dataset
    generate_streaming_dataset(total_samples=samples, output_path=output)

def train_models_cmd(dataset="data/dataset.jsonl", batch_size=50000):
    """Trains Pure-NumPy Ensembles & Autoencoder on streaming dataset."""
    from tools.train_ai_models import train_streaming_ensemble, train_streaming_autoencoder
    train_streaming_ensemble(dataset_path=dataset, batch_size=batch_size)
    train_streaming_autoencoder(dataset_path=dataset, batch_size=batch_size)

def doctor_cmd():
    """Runs a complete self-diagnostic health check across all SIEM engines."""
    print("=" * 75)
    print("       ENTERPRISE SIEM SYSTEM DOCTOR & ENVIRONMENT DIAGNOSTICS")
    print("=" * 75)
    
    import platform
    print(f"[*] OS Platform        : {platform.system()} {platform.release()} ({platform.machine()})")
    print(f"[*] Python Version     : {platform.python_version()} ({sys.executable})")
    
    db_path = os.path.abspath("security_events.db")
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("PRAGMA journal_mode;")
            jmode = cursor.fetchone()[0]
            cursor.execute("SELECT count(*) FROM banned_ips;")
            ban_cnt = cursor.fetchone()[0]
            cursor.execute("SELECT count(*) FROM activity_logs;")
            log_cnt = cursor.fetchone()[0]
            print(f"[OK] SQLite DB Engine  : WAL Mode ({jmode.upper()}) | Active Bans: {ban_cnt} | Logs: {log_cnt} | File: {db_path}")
    except Exception as e:
        print(f"[FAIL] SQLite DB Engine: Error ({e})")

    from modules.ai_security_engine import AISecurityEngine
    try:
        ai = AISecurityEngine()
        loaded = ai.load_all_models()
        if loaded:
            print(f"[OK] AI Security Engine: 4 Ensemble Models + Zero-Day Autoencoder LOADED (Pure-NumPy, Zero PyTorch)")
        else:
            print(f"[WARN] AI Security Engine: Model files missing in models/ directory")
    except Exception as e:
        print(f"[FAIL] AI Security Engine: Error ({e})")

    from modules.ban_manager import BanManager
    try:
        bm = BanManager()
        prot_ips = list(bm.dynamic_protected_ips)[:5]
        print(f"[OK] Perimeter Shield  : Host IPs Whitelisted ({len(bm.dynamic_protected_ips)} protected): {', '.join(prot_ips)}")
    except Exception as e:
        print(f"[FAIL] Perimeter Shield: Error ({e})")

    try:
        cpu = psutil.cpu_percent(interval=0.1)
        mem = psutil.virtual_memory().percent
        disk = psutil.disk_usage('.').percent
        print(f"[OK] System Resources  : CPU: {cpu}% | RAM: {mem}% | Disk: {disk}%")
    except Exception as e:
        print(f"[FAIL] System Resources: Error ({e})")

    try:
        users = psutil.users()
        print(f"[OK] Interactive Users : {len(users)} active user session(s) detected via psutil.")
        for u in users:
            print(f"      - User: {u.name} | TTY: {u.terminal} | Remote Host: {u.host or 'local'}")
    except Exception as e:
        print(f"[WARN] Interactive Users: {e}")

    print("=" * 75)
    print("[+] System Health Status: READY & FULLY OPERATIONAL")
    print("=" * 75)

def scan_cmd(payload: str):
    """Performs deep-dive forensic threat assessment on any command or log string."""
    print("=" * 75)
    print("       DEEP-DIVE FORENSIC THREAT ASSESSMENT & AI INSPECTION")
    print("=" * 75)
    print(f"[*] Target Input       : {payload}")
    
    from modules.ai_security_engine import AISecurityEngine
    from modules.user_session_tracker import UserSessionTracker
    from modules.canonicalizer import PayloadCanonicalizer
    from modules.whitelist_shield import WhitelistShield
    
    canonical = PayloadCanonicalizer.canonicalize(payload)
    print(f"[*] Canonicalized      : {canonical}")
    
    is_whitelisted = WhitelistShield.is_known_benign(payload) or WhitelistShield.is_known_benign(canonical)
    print(f"[*] Whitelist Shield   : {'MATCHED (Known Benign)' if is_whitelisted else 'NONE (Proceeds to Deep Analysis)'}")
    
    ai = AISecurityEngine()
    ai.load_all_models()
    tracker = UserSessionTracker(ai_engine=ai)
    
    cat, score, is_anom, summary, ai_res, urgency = tracker.analyze_command_context("forensic_admin", payload)
    
    verdict = "MALICIOUS / HOSTILE" if (is_anom or score >= 60) else "BENIGN / ALLOWED"
    print("-" * 75)
    print(f"[*] FINAL VERDICT      : {verdict}")
    print(f"[*] Threat Category    : {cat}")
    print(f"[*] Risk Score         : {score}/100")
    print(f"[*] Urgency Level      : {urgency}")
    print(f"[*] Summary            : {summary}")
    if ai_res:
        print(f"[*] AI Anomaly Score   : {ai_res.get('anomaly_score', 0.0):.6f} (Threshold: {ai_res.get('autoencoder_threshold', 0.0):.6f})")
        print(f"[*] AI Probability     : {ai_res.get('confidence_score', 0.0)*100:.1f}%")
        print(f"[*] Threat Title       : {ai_res.get('incident_title', 'N/A')}")
        print(f"[*] MITRE ATT&CK       : {ai_res.get('mitre_id', 'N/A')}")
    print("=" * 75)

def main():
    parser = argparse.ArgumentParser(
        description="Enterprise SIEM Management, Testing & Interactive SOC Controller",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    subparsers = parser.add_subparsers(dest="command", help="Available Operations")

    # 1. Daemon Lifecycle
    p_start = subparsers.add_parser("start", help="Start SIEM daemon")
    p_start.add_argument("--mode", type=str, default="production", choices=["production", "dry-run"], help="Operating mode")
    p_start.add_argument("--daemon", "-d", action="store_true", help="Run detached in background")
    p_start.add_argument("--port", type=int, default=None, help="Override Syslog port")

    p_stop = subparsers.add_parser("stop", help="Stop SIEM daemon")

    p_restart = subparsers.add_parser("restart", help="Restart SIEM daemon")
    p_restart.add_argument("--mode", type=str, default="production", choices=["production", "dry-run"])

    subparsers.add_parser("audit", help="Run SIEM in foreground Warning-Only / Dry-Run mode")

    # 2. Testing & Simulation
    p_test = subparsers.add_parser("test", help="Run 17-point automated verification suite")
    p_test.add_argument("--verbose", "-v", action="store_true", help="Verbose test diagnostics")

    subparsers.add_parser("benchmark", help="Run AI Security Benchmark (25 Scenarios)")
    subparsers.add_parser("benchmark1000", help="Run 1,000 Scenario Enterprise Stress-Test Benchmark")
    subparsers.add_parser("benchmark10000", help="Run 10,000 Scenario Enterprise Realistic Stress-Test Benchmark")
    p_sim = subparsers.add_parser("simulate", help="Simulate single command string evaluation")
    p_sim.add_argument("payload", type=str, help="Command string to evaluate")

    subparsers.add_parser("simulate-shell", help="Interactive threat simulation REPL")

    # 3. Logs & Observability
    subparsers.add_parser("status", help="Show system overview, bans, and active sessions")
    subparsers.add_parser("monitor", help="Live interactive terminal SOC dashboard")
    subparsers.add_parser("top", help="Alias for monitor")

    p_logs = subparsers.add_parser("logs", help="Query activity logs")
    p_logs.add_argument("--limit", type=int, default=20, help="Number of records")
    p_logs.add_argument("--level", type=str, default=None, help="Filter by severity")
    p_logs.add_argument("--event-type", type=str, default=None, help="Filter by event")
    p_logs.add_argument("--json", action="store_true", help="Print JSON")

    p_ua = subparsers.add_parser("user-audit", help="Audit user activities")
    p_ua.add_argument("user", type=str, help="Target username")
    p_ua.add_argument("--limit", type=int, default=20)

    p_tail = subparsers.add_parser("tail", help="Tail live log files")
    p_tail.add_argument("--follow", "-f", action="store_true", help="Continuous follow")
    p_tail.add_argument("--lines", "-n", type=int, default=15, help="Number of initial lines")

    p_vi = subparsers.add_parser("verify-integrity", help="Verify HMAC-SHA256 log chain integrity")
    p_vi.add_argument("--file", type=str, default="logs/activity_records.jsonl")

    p_exp = subparsers.add_parser("export-report", help="Export SIEM metrics as JSON")
    p_exp.add_argument("--output", "-o", type=str, default="siem_security_report.json")

    # 4. Security & Threat Intelligence
    p_cti = subparsers.add_parser("cti-check", help="Query CTI threat feeds for an IP or domain")
    p_cti.add_argument("target", type=str, help="IP or domain name to query")

    p_dga = subparsers.add_parser("dga-check", help="Evaluate DGA score & Shannon entropy for a domain")
    p_dga.add_argument("domain", type=str, help="Domain name to check")

    p_risk = subparsers.add_parser("risk", help="View or adjust dynamic risk score")
    p_risk.add_argument("entity", type=str, help="User or host entity name")
    p_risk.add_argument("--add", type=float, default=None, help="Points to add")
    p_risk.add_argument("--reason", type=str, default="Manual adjustment via manage.py")
    p_risk.add_argument("--is-host", action="store_true", help="Entity is a host IP rather than user")

    p_mem = subparsers.add_parser("memory-scan", help="Run process memory RWX & YARA scan")
    p_mem.add_argument("--pid", type=int, default=None, help="Target specific PID")

    # 5. Perimeter & Sessions
    p_ban = subparsers.add_parser("ban", help="Manually ban an IP or Subnet CIDR")
    p_ban.add_argument("ip", type=str, help="IP address or CIDR subnet")
    p_ban.add_argument("--duration", type=int, default=None, help="Duration in seconds")
    p_ban.add_argument("--criticality", type=str, default="CRITICAL", choices=["CRITICAL", "HIGH", "MEDIUM", "LOW"])
    p_ban.add_argument("--reason", type=str, default="Manual Administrator Ban")

    p_unban = subparsers.add_parser("unban", help="Lift firewall ban for an IP or Subnet")
    p_unban.add_argument("ip", type=str, help="Target IP or CIDR")

    subparsers.add_parser("unban-all", help="Lift all active firewall bans")

    p_lbans = subparsers.add_parser("list-bans", help="List recent and active bans")
    p_lbans.add_argument("--active-only", action="store_true", help="List only currently active unexpired bans")
    p_lbans.add_argument("--limit", type=int, default=20)

    p_sess = subparsers.add_parser("sessions", help="List or terminate active terminal sessions")
    p_sess.add_argument("--kill", type=str, default=None, help="Kill session by TTY or Username")

    subparsers.add_parser("doctor", help="Run comprehensive system health check and diagnostics")
    
    p_scan = subparsers.add_parser("scan", help="Deep-dive forensic threat inspection on any command or payload")
    p_scan.add_argument("payload", type=str, help="Command string or log to inspect")

    # 6. Tooling & Dataset Generation
    p_gdata = subparsers.add_parser("generate-dataset", help="Generate synthetic training logs")
    p_gdata.add_argument("--samples", type=int, default=5000, help="Number of log lines to generate")
    p_gdata.add_argument("--output", type=str, default="data/dataset.jsonl", help="Output file path")

    p_train = subparsers.add_parser("train-models", help="Train Pure-NumPy Ensembles & Autoencoder")
    p_train.add_argument("--dataset", type=str, default="data/dataset.jsonl", help="Dataset path")
    p_train.add_argument("--batch-size", type=int, default=50000, help="Streaming batch size")

    args = parser.parse_args()

    # Dispatch Command
    if args.command == "start":
        start_daemon_cmd(mode=args.mode, daemon=args.daemon, port=args.port)
    elif args.command == "stop":
        stop_daemon_cmd()
    elif args.command == "restart":
        restart_daemon_cmd(mode=args.mode)
    elif args.command == "audit":
        start_daemon_cmd(mode="dry-run", daemon=False)
    elif args.command == "doctor":
        doctor_cmd()
    elif args.command == "scan":
        scan_cmd(args.payload)
    elif args.command == "test":
        run_tests_cmd(verbose=args.verbose)
    elif args.command == "benchmark":
        run_benchmark_cmd()
    elif args.command in ["benchmark1000", "benchmark-1000"]:
        run_benchmark_1000_cmd()
    elif args.command in ["benchmark10000", "benchmark-10000"]:
        run_benchmark_10000_cmd()
    elif args.command == "simulate":
        simulate_command_cmd(args.payload)
    elif args.command == "simulate-shell":
        simulate_shell_cmd()
    elif args.command in ["monitor", "top"]:
        run_live_monitor()
    elif args.command == "status" or not args.command:
        show_status()
    elif args.command == "logs":
        list_logs_cmd(limit=args.limit, level=args.level, event_type=args.event_type, as_json=args.json)
    elif args.command == "user-audit":
        user_audit_cmd(user=args.user, limit=args.limit)
    elif args.command == "tail":
        tail_logs_cmd(follow=args.follow, lines=args.lines)
    elif args.command == "verify-integrity":
        verify_log_integrity_cmd(args.file)
    elif args.command == "export-report":
        export_report(args.output)
    elif args.command == "cti-check":
        cti_check_cmd(args.target)
    elif args.command == "dga-check":
        dga_check_cmd(args.domain)
    elif args.command == "risk":
        risk_cmd(args.entity, add_points=args.add, reason=args.reason, is_host=args.is_host)
    elif args.command == "memory-scan":
        memory_scan_cmd(pid=args.pid)
    elif args.command == "ban":
        ban_ip_cmd(args.ip, duration=args.duration, criticality=args.criticality, reason=args.reason)
    elif args.command == "unban":
        unban_ip_cmd(args.ip)
    elif args.command == "unban-all":
        unban_all_cmd()
    elif args.command == "list-bans":
        list_all_bans(active_only=args.active_only, limit=args.limit)
    elif args.command == "sessions":
        sessions_cmd(kill_target=args.kill)
    elif args.command == "generate-dataset":
        generate_dataset_cmd(samples=args.samples, output=args.output)
    elif args.command == "train-models":
        train_models_cmd(dataset=args.dataset, batch_size=args.batch_size)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
